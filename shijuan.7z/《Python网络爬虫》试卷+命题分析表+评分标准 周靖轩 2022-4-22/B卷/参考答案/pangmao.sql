CREATE DATABASE dianying1905;
USE dianying1905 ;

CREATE TABLE tsinfo (
    ts_id               INTEGER PRIMARY KEY AUTO_INCREMENT, -- 影片编号
    ts_name             VARCHAR(100) NOT NULL,              -- 影片名称
    ts_picture_url      VARCHAR(500) NOT NULL,              -- 图片url
);

