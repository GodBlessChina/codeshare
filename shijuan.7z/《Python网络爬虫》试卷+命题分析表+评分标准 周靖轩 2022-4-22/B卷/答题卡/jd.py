import pymysql
import requests
from bs4 import BeautilSoup4 as bs
url = 'https://www.1905.com/vod/list/n_1_a_4/o1p1.html'
imgs = bs(requests.get(url).text,'html.parser').select('img')
db = pymysql.connect("localhost","root","root","dianying1905" )
cursor = db.cursor()
for img in imgs:
    f=open(img.text,'wb')
    f.write(requests.get(img['href']).content)
    f.close()
    cursor.execute("INSERT INTO tsinfo VALUES(NULL,{},{})".format(img.text,img['href']))
db.close()
